import rclpy

from rclpy.node import Node

from sensor_msgs.msg import JointState

from std_srvs.srv import Trigger


class ArmGripperServer(Node):

    def __init__(self):

        super().__init__('arm_gripper_server')

        self.pub = self.create_publisher(
            JointState,
            '/joint_states',
            10
        )

        self.gripper_open_srv = self.create_service(
            Trigger,
            '/gripper_open',
            self.gripper_open_callback
        )

        self.gripper_close_srv = self.create_service(
            Trigger,
            '/gripper_close',
            self.gripper_close_callback
        )

        self.get_logger().info('Arm Gripper Server Ready')

    def publish_joint_state(
        self,
        shoulder_pan,
        shoulder_lift,
        elbow,
        wrist1,
        wrist2,
        wrist3,
        gripper
    ):

        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = [
            'shoulder_pan_joint',
            'shoulder_lift_joint',
            'elbow_joint',
            'wrist_1_joint',
            'wrist_2_joint',
            'wrist_3_joint',
            'robotiq_85_left_knuckle_joint'
        ]

        msg.position = [
            shoulder_pan,
            shoulder_lift,
            elbow,
            wrist1,
            wrist2,
            wrist3,
            gripper
        ]

        self.pub.publish(msg)

    def gripper_open_callback(self, request, response):

        self.publish_joint_state(
            0.0,
            -1.57,
            1.57,
            0.0,
            0.0,
            0.0,
            0.0
        )

        response.success = True
        response.message = 'gripper opened'

        return response

    def gripper_close_callback(self, request, response):

        self.publish_joint_state(
            0.0,
            -1.57,
            1.57,
            0.0,
            0.0,
            0.0,
            0.8
        )

        response.success = True
        response.message = 'gripper closed'

        return response


def main():

    rclpy.init()

    node = ArmGripperServer()

    rclpy.spin(node)

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()


